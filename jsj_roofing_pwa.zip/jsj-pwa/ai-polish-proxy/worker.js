/**
 * JSJ Roofing — AI Report Polish Proxy
 * Deploy this as a Cloudflare Worker (free tier is plenty for this use case).
 *
 * WHY THIS EXISTS:
 * The JSJ Roofing app is a static, client-side PWA — all its code is visible
 * in the browser. The Anthropic API key must NEVER be placed directly in
 * the app's JavaScript, because anyone could view it and use the account,
 * running up charges on the bill.
 *
 * This worker sits in between: the app calls THIS worker (no key needed),
 * and the worker calls Anthropic's API using the key stored securely as a
 * Cloudflare "secret" (never visible in code or to end users).
 *
 * ──────────────────────────────────────────────────────────────────────────
 * DEPLOYMENT STEPS (one-time, ~10 minutes):
 * ──────────────────────────────────────────────────────────────────────────
 * 1. Go to https://dash.cloudflare.com and sign up / log in (free account).
 * 2. In the left sidebar, click "Workers & Pages" → "Create" → "Create Worker".
 * 3. Give it a name, e.g. "jsj-ai-polish-proxy". Click "Deploy" to create
 *    the shell.
 * 4. Click "Edit code" and paste this ENTIRE file in, replacing the default
 *    code.
 * 5. Click "Save and Deploy".
 * 6. Go to the Worker's "Settings" tab → "Variables and Secrets".
 * 7. Add a new variable:
 *      Name:  ANTHROPIC_API_KEY
 *      Value: (paste a real Anthropic API key — get one from
 *              https://console.anthropic.com/settings/keys if needed)
 *      IMPORTANT: Add it as a "Secret" (encrypted), not plain text.
 * 8. Save. The worker is now live at a URL like:
 *      https://jsj-ai-polish-proxy.YOUR-SUBDOMAIN.workers.dev
 * 9. Paste that URL into the app's admin settings:
 *      Admin → ✨ AI Polish → Proxy server URL
 *
 * ──────────────────────────────────────────────────────────────────────────
 * WHAT THIS WORKER DOES:
 * ──────────────────────────────────────────────────────────────────────────
 * - Accepts a POST request with JSON body: { "report": "...report text..." }
 * - Sends that text to Claude with instructions to polish the wording while
 *   keeping all facts identical.
 * - Returns the polished text back to the app as JSON: { "polished": "..." }
 *
 * Billing note: each polish request costs a small fraction of a cent.
 * Normal day-to-day use by field staff will not run up meaningful costs,
 * but it's worth keeping an eye on usage at
 * https://console.anthropic.com/settings/usage if a large team uses this.
 */

export default {
  async fetch(request, env) {
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    if (request.method !== 'POST') {
      return new Response(JSON.stringify({ error: 'Use POST with a JSON body: { "report": "..." }' }), {
        status: 405,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!env.ANTHROPIC_API_KEY) {
      return new Response(
        JSON.stringify({ error: 'Server misconfigured: ANTHROPIC_API_KEY not set' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let body;
    try {
      body = await request.json();
    } catch (e) {
      return new Response(JSON.stringify({ error: 'Invalid JSON body' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const reportText = (body.report || '').trim();
    if (!reportText) {
      return new Response(JSON.stringify({ error: 'Missing "report" field in request body' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    try {
      const anthropicRes = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': env.ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-5',
          max_tokens: 1200,
          system: `You are an expert report writer for JSJ Roofing, a professional Australian roofing company.
Your job is to rewrite field technician reports (leak reports, roof inspection reports, gutter clean reports) to sound polished, professional and client-ready — suitable for strata managers and property managers.

Rules:
- Keep all the factual content, numbers, prices and details exactly the same — do not add, invent or remove any facts
- Use formal, professional Australian English
- Improve sentence structure, grammar and flow
- Use industry-appropriate roofing terminology where suitable
- Preserve any clearly structured sections (e.g. headings, bullet/scope lists, pricing lines) — only smooth out the prose/narrative parts, don't rewrite line-item lists into paragraphs
- Keep it concise — do not pad or repeat information
- Output ONLY the rewritten report text, nothing else — no preamble, no explanation, no quotation marks around the whole thing`,
          messages: [
            {
              role: 'user',
              content: `Please rewrite this report to sound more professional:\n\n${reportText}`,
            },
          ],
        }),
      });

      if (!anthropicRes.ok) {
        const errBody = await anthropicRes.json().catch(() => ({}));
        return new Response(
          JSON.stringify({
            error: errBody?.error?.message || `Anthropic API error (status ${anthropicRes.status})`,
          }),
          { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const data = await anthropicRes.json();
      const polished = data.content?.find((b) => b.type === 'text')?.text?.trim();

      if (!polished) {
        return new Response(JSON.stringify({ error: 'No text returned from AI' }), {
          status: 502,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ polished }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    } catch (err) {
      return new Response(JSON.stringify({ error: 'Unexpected error', detail: String(err) }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  },
};
