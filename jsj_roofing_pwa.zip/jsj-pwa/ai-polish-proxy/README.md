# JSJ Roofing — AI Polish Proxy Setup

## Why this exists

The JSJ Roofing app is a client-side web app — all of its code runs in the
browser and can be viewed by anyone using it. The Anthropic API key must
**never** be placed directly inside the app, because it would be visible to
every field staff member (or anyone they forward the link to), and could be
copied and used to run up charges on the Anthropic billing account.

This `worker.js` file is a small proxy server that sits between the app and
Anthropic. The app sends the report text to this proxy (no key required),
the proxy calls Anthropic using the key (kept secret on Cloudflare's
servers), and only the polished text is sent back to the app.

## What you need

- An Anthropic API key — get one at
  https://console.anthropic.com/settings/keys (a small amount of billing
  credit is needed; polishing a report costs a tiny fraction of a cent per
  use)
- A free Cloudflare account — https://dash.cloudflare.com/sign-up
- About 10 minutes

## Setup steps

1. Go to https://dash.cloudflare.com and log in.
2. Left sidebar → **Workers & Pages** → **Create** → **Create Worker**.
3. Name it something like `jsj-ai-polish-proxy`, click **Deploy** to create
   the default shell.
4. Click **Edit code**. Delete everything in the editor and paste in the
   full contents of `worker.js` (included in this folder).
5. Click **Save and Deploy**.
6. Go to the Worker's **Settings** tab → **Variables and Secrets**.
7. Add a new variable:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** *(paste the real Anthropic API key)*
   - Make sure it's added as a **Secret** (encrypted), not plain text.
8. Save.
9. The worker is now live at a URL like:
   `https://jsj-ai-polish-proxy.<your-subdomain>.workers.dev`

## Testing it

```bash
curl -X POST https://jsj-ai-polish-proxy.<your-subdomain>.workers.dev \
  -H "Content-Type: application/json" \
  -d '{"report":"we went to the roof and fixed a leak near the chimney, tile was cracked"}'
```

Expected response:
```json
{"polished":"Our technicians attended site and identified a cracked roof tile near the chimney, which was the source of the reported leak. The damaged tile was repaired accordingly."}
```

If you get an error JSON response instead, check the `error` field — common
issues are a missing/incorrect API key, or insufficient billing credit.

## Connecting it to the app

Once deployed and tested, paste the worker's base URL into the app:

**Admin → ✨ AI Polish → Proxy server URL**

The "Polish with AI" button will then appear on every report output page
(Leak Report, Roof Inspection, Gutter Clean Quote, Gutter Clean / Roof
Report) and will POST the report text to this worker whenever tapped.

## Which part of each report gets polished

- **Leak Report** — only the written narrative report is sent for
  polishing. The Scope of Works / Quote text is left untouched, since it's
  a structured price list rather than prose.
- **Roof Inspection, Gutter Clean Quote, Gutter Clean / Roof Report** — the
  whole report textarea is sent, since these reports combine narrative and
  scope into a single block with no separate field for just the written
  part. The system prompt is written to preserve any line-item/bullet
  sections rather than turning them into paragraphs.

## Notes

- Each polish request is a small, normal AI API call — costs a fraction of
  a cent. Keep an eye on usage at
  https://console.anthropic.com/settings/usage if a large team uses this
  feature regularly.
- If Anthropic ever changes their API or model names, the `model` field
  inside `worker.js` may need updating — check https://docs.claude.com for
  current model names.
- The "Polish with AI" button is hidden everywhere in the app until a
  proxy URL is saved in Admin — so field staff won't see a button that
  doesn't work yet.
